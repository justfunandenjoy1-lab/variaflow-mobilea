# VariaFlow Mobile

A local/offline Android video conversion and optimization app. Kotlin + Jetpack Compose +
[Media3 Transformer](https://developer.android.com/media/media3/transformer) for on-device
decode → encode → mux. No backend, no login, no activation system, no network permission
requested anywhere in the manifest — every byte of video stays on the device.

## What's in this build

- **Select Video** — pick one or more videos via the system document picker (Storage Access
  Framework), so no storage permission is needed just to read a file the user chose.
- **Video Information** — file name, size, duration, resolution, fps, video/audio codec,
  bitrate, container, sample rate, channel count, read via `MediaExtractor` /
  `MediaMetadataRetriever`.
- **Presets** — High Quality, Balanced, Small File, and Custom, each mapping to a concrete
  resolution/codec/bitrate combination (`data/Models.kt` → `ProcessingSettings.forPreset`).
- **Processing** — runs in a foreground `Service` (`service/ProcessingService.kt`) via Media3
  `Transformer`, so a conversion keeps running even if the app is backgrounded, with a
  progress notification.
- **Quality warnings** — before processing, `media/QualityAdvisor.kt` flags settings likely to
  hurt visible quality (upscaling, too-low bitrate, requesting a higher fps than the source
  actually has, etc.).
- **Before/after comparison screen** — resolution, fps, bitrate, size (with % change), and
  codec, original vs. output.
- **Batch queue** — processes multiple picked videos one after another, showing current /
  completed / failed / remaining, with per-item cancel.
- **Output** — saved to `Movies/VariaFlow/Output/` via `MediaStore` (visible in any gallery/
  file app, survives the app being uninstalled, needs no storage permission on Android 10+),
  as `<name>_001_processed.mp4`, `_002_`, etc. so nothing is overwritten.
- **Error handling** — corrupted files, unsupported formats/codecs, low storage, and
  processing failures all surface as a plain-language message (`util/ProcessingException.kt`),
  not a stack trace.
- **Light/dark theme**, following the system setting.

## Scope decisions — read this before opening an issue against yourself later

Two places where I made a deliberate engineering trade-off rather than silently guessing:

**Output container is MP4 only.** Media3's stable `Transformer` output path targets MP4.
Writing MKV or MOV directly would mean either bundling FFmpeg (a real native-build undertaking:
per-ABI `.so` compilation, ~15-20MB+ added to the APK per architecture, LGPL/GPL licensing
terms to track) or an experimental Matroska muxer. Rather than ship code that looks like it
supports MKV/MOV but silently produces a broken or mislabeled file, the Settings screen shows
those two as visibly disabled ("not supported in this build") and the app only ever writes
`.mp4`. This matches spec section 2's own fallback — "if a format is unsupported, show a clear
error message" — applied honestly to output as well as input.

**AVI input is rejected with a clear message, not silently mis-decoded.** Android's built-in
`MediaExtractor` has no AVI demuxer; MP4, MOV, MKV, and WebM containers all extract natively on
every device. `media/SupportedFormats.kt` checks this *before* the picker even hands a file to
the processor, so selecting an AVI shows a specific explanation instead of a confusing failure
mid-conversion.

**Target FPS is a heads-up, not a resample.** As of media3-transformer 1.10.x there's no public
"re-encode at N fps" knob — encoding runs at the source's own frame rate. Picking a different
fps in Settings still feeds `QualityAdvisor`, which will tell you if your target is unrealistic
relative to the source, but it won't currently duplicate/drop frames to hit that number. This is
flagged in code (`media/VideoProcessor.kt`) as the first thing to revisit if a future Media3
release adds real frame-rate conversion.

None of these affect the core ask — pick a video, convert/compress it on-device, see before/
after, manage a batch, never touch the network — they're just the honest edges of "no FFmpeg."

## Project layout

```
app/src/main/java/com/variaflow/mobile/
  MainActivity.kt          – hosts the document picker + notification permission request
  VariaFlowApplication.kt
  data/Models.kt           – VideoMetadata, ProcessingSettings, presets, job/state types
  media/
    VideoInfoExtractor.kt  – reads source/output metadata
    SupportedFormats.kt    – input format gate (spec §2)
    QualityAdvisor.kt      – pre-flight quality warnings (spec §6)
    VideoProcessor.kt      – the Media3 Transformer wrapper (spec §5)
  storage/OutputFileManager.kt – scratch file + MediaStore publish + unique naming (spec §10)
  service/
    ProcessingRepository.kt – shared job queue (StateFlow), UI and Service both read/write it
    ProcessingService.kt    – foreground service draining the queue (spec §8/§9)
  util/
    ProcessingException.kt – friendly error messages (spec §11)
    FormatUtils.kt, PermissionUtils.kt
  viewmodel/MainViewModel.kt
  ui/
    VariaFlowApp.kt, navigation/Screen.kt
    screens/HomeScreen.kt, screens/ComparisonScreen.kt
    components/ (info cards, settings form, batch rows, warning banner, presets)
    theme/ (Color.kt, Theme.kt, Type.kt)
```

## Building the APK

This project was written and reviewed in a sandbox with no internet access and no Android SDK,
so I could not run Gradle here to hand you a compiled `.apk` directly — Gradle needs to
download the Android Gradle Plugin, Kotlin compiler, and every dependency listed in
`app/build.gradle.kts` from Google's/Maven's servers the first time it syncs. What's in this
project is the complete, ready-to-open source; building it is one normal Android Studio flow:

1. Install **Android Studio** (Ladybird/current stable or newer) if you don't have it:
   https://developer.android.com/studio
2. **File → Open**, select the unzipped `VariaFlowMobile` folder.
3. Let Gradle sync. `gradle/wrapper/gradle-wrapper.jar` (the small binary that makes `./gradlew`
   work from a terminal) isn't included — this sandbox can't fetch binaries either — but you
   don't need it: Android Studio bundles its own Gradle and will sync the project directly. If
   it prompts anything like "Gradle wrapper not found, use local Gradle distribution?", accept
   it. If Android Studio suggests upgrading the Android Gradle Plugin/Kotlin/compileSdk version
   shown in the two `build.gradle.kts` files, that's fine to accept — those numbers move fast
   and Studio's suggestion will be more current than what's pinned here.
4. Once sync finishes: **Build → Build Bundle(s) / APK(s) → Build APK(s)**, or just press the
   green ▶ Run button with a device/emulator selected — either produces
   `app/build/outputs/apk/debug/app-debug.apk`.
5. Install it: drag the APK onto a running emulator, or `adb install app-debug.apk` with a
   device connected over USB debugging.

**Testing tip:** the emulator's default AVD often has no sample videos. Either `adb push` a
short MP4 to the emulator's `Downloads` folder first, or just run on a real device where you
already have some.

## Where a production version diverges (per spec §18, not built here)

The code is structured so none of this requires restructuring later: `VariaFlowApplication`,
`ProcessingSettings`, and `ProcessingJob` are the natural places to hang, respectively, app-wide
init, a license/entitlement check gating `startProcessing()`, and a `deviceId`/subscription
field — but no server, activation code, or device-binding logic exists in this build, as
specified.
