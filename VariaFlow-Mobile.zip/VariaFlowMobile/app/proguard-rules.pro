# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.kts.

# Media3 / ExoPlayer / Transformer ship their own consumer-rules.pro files
# inside their AARs, so no manual -keep rules are required for them here.

# Keep line numbers for readable stack traces from crash reports.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
