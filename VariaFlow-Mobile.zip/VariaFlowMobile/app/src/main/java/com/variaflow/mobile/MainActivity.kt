package com.variaflow.mobile

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.LaunchedEffect
import com.variaflow.mobile.storage.OutputFileManager
import com.variaflow.mobile.ui.VariaFlowApp
import com.variaflow.mobile.ui.theme.VariaFlowTheme
import com.variaflow.mobile.util.PermissionUtils
import com.variaflow.mobile.viewmodel.MainViewModel

/**
 * The app's only screen host. All real UI state lives in [MainViewModel] / [VariaFlowApp] —
 * this class exists to own the two things that must be an Activity: the document-picker launcher
 * (spec section 2, video selection from device storage) and the runtime notification permission
 * request that lets [com.variaflow.mobile.service.ProcessingService]'s progress notification show.
 */
class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pickVideosLauncher = registerForActivityResult(
            ActivityResultContracts.OpenMultipleDocuments()
        ) { uris -> if (uris.isNotEmpty()) viewModel.onVideosPicked(uris) }

        val notificationPermissionLauncher = registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { /* Declining just means the foreground notification won't show; processing still runs. */ }

        setContent {
            VariaFlowTheme {
                LaunchedEffect(Unit) {
                    if (PermissionUtils.notificationPermissionRequired() &&
                        !PermissionUtils.hasNotificationPermission(this@MainActivity)
                    ) {
                        notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                }

                VariaFlowApp(
                    viewModel = viewModel,
                    onPickVideos = {
                        // Broad video/* on purpose — SupportedFormats.check() gives a clear,
                        // specific reason for anything picked here that VariaFlow can't decode
                        // (e.g. AVI), rather than pre-filtering the system picker silently.
                        pickVideosLauncher.launch(arrayOf("video/*"))
                    },
                    onPlayVideo = { uri -> startActivity(OutputFileManager.viewIntent(uri)) },
                    onOpenOutputFolder = {
                        runCatching { startActivity(OutputFileManager.openFolderIntent()) }.onFailure {
                            // Folder-browsing intents aren't guaranteed to resolve on every OEM's
                            // file manager — fall back to simply playing the newest processed file.
                            viewModel.jobs.value.lastOrNull { it.result != null }?.result?.outputUri?.let { uri ->
                                startActivity(OutputFileManager.viewIntent(uri))
                            }
                        }
                    }
                )
            }
        }
    }
}
