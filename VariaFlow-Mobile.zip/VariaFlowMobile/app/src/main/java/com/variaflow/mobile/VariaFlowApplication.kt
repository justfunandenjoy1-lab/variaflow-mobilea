package com.variaflow.mobile

import android.app.Application

/**
 * Nothing to initialize globally yet — VariaFlow has no analytics, no crash reporter phoning
 * home, and no cloud SDKs to set up (spec section 14: no unnecessary data collection). This
 * class exists mainly as the documented extension point future modules (e.g. section 18's
 * optional licensing layer) would hook into, and because android:name in the manifest expects
 * a concrete Application class to exist.
 */
class VariaFlowApplication : Application()
