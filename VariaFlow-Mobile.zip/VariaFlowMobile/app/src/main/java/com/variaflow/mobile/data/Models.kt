package com.variaflow.mobile.data

import android.net.Uri

/**
 * Everything the app knows about a video file, gathered either from the
 * source file before processing, or from the file VariaFlow just produced.
 */
data class VideoMetadata(
    val displayName: String,
    val uri: Uri,
    val fileSizeBytes: Long,
    val durationMs: Long,
    val width: Int,
    val height: Int,
    val frameRate: Float,
    val videoCodec: String,
    val audioCodec: String?,
    val bitrateBps: Long,
    val containerLabel: String,
    val audioSampleRateHz: Int?,
    val audioChannelCount: Int?
)

/** Containers VariaFlow recognizes as *input*. Not all of them can be decoded on-device. */
enum class InputContainer(
    val extensions: List<String>,
    val label: String,
    /** True if Android's own MediaExtractor can demux this container without extra components. */
    val nativelySupported: Boolean
) {
    MP4(listOf("mp4", "m4v"), "MP4", nativelySupported = true),
    MOV(listOf("mov", "qt"), "MOV / QuickTime", nativelySupported = true),
    MKV(listOf("mkv"), "MKV / Matroska", nativelySupported = true),
    WEBM(listOf("webm"), "WebM", nativelySupported = true),
    AVI(listOf("avi"), "AVI", nativelySupported = false),
    UNKNOWN(emptyList(), "Unknown format", nativelySupported = false);

    companion object {
        fun fromFileName(name: String): InputContainer {
            val ext = name.substringAfterLast('.', missingDelimiterValue = "").lowercase()
            return entries.firstOrNull { ext in it.extensions } ?: UNKNOWN
        }
    }
}

/** Containers VariaFlow can write as *output*. Only MP4 is produced by this build — see README. */
enum class OutputContainer(val extension: String, val label: String, val supported: Boolean) {
    MP4("mp4", "MP4", supported = true),
    MKV("mkv", "MKV", supported = false),
    MOV("mov", "MOV", supported = false)
}

enum class VideoCodecOption(val mimeType: String, val label: String) {
    H264("video/avc", "H.264 (AVC) — widest compatibility"),
    H265("video/hevc", "H.265 (HEVC) — smaller files")
}

enum class AudioCodecOption(val mimeType: String, val label: String) {
    AAC("audio/mp4a-latm", "AAC")
}

enum class ResolutionOption(val width: Int?, val height: Int?, val label: String) {
    ORIGINAL(null, null, "Original resolution"),
    UHD_2160(3840, 2160, "2160p (4K)"),
    FHD_1080(1920, 1080, "1080p (Full HD)"),
    HD_720(1280, 720, "720p (HD)"),
    SD_480(854, 480, "480p"),
    CUSTOM(null, null, "Custom")
}

enum class FpsOption(val fps: Int?, val label: String) {
    ORIGINAL(null, "Match source"),
    FPS_60(60, "60 fps"),
    FPS_30(30, "30 fps"),
    FPS_24(24, "24 fps"),
    CUSTOM(null, "Custom")
}

enum class QualityTier(val label: String, val description: String) {
    HIGH_QUALITY("High Quality", "Keeps the original resolution and uses a high bitrate"),
    BALANCED("Balanced", "1080p at a bitrate that keeps files reasonably small"),
    SMALL_FILE("Small File", "720p, H.265, tuned for the smallest output"),
    CUSTOM("Custom", "Choose every setting yourself")
}

/**
 * The full set of choices that feed into [com.variaflow.mobile.media.VideoProcessor].
 * Presets are just convenient starting points — [QualityTier.CUSTOM] lets every field
 * below be picked by hand, and picking any single field away from a preset's defaults
 * on the Settings screen re-labels the preset as Custom.
 */
data class ProcessingSettings(
    val preset: QualityTier,
    val outputContainer: OutputContainer = OutputContainer.MP4,
    val resolution: ResolutionOption = ResolutionOption.ORIGINAL,
    val customWidth: Int? = null,
    val customHeight: Int? = null,
    val fps: FpsOption = FpsOption.ORIGINAL,
    val customFps: Int? = null,
    val videoCodec: VideoCodecOption = VideoCodecOption.H264,
    val videoBitrateBps: Int = 8_000_000,
    val audioCodec: AudioCodecOption = AudioCodecOption.AAC,
    val audioBitrateBps: Int = 128_000,
    val audioSampleRateHz: Int = 44_100,
    val audioChannelCount: Int = 2
) {
    val effectiveWidth: Int? get() = if (resolution == ResolutionOption.CUSTOM) customWidth else resolution.width
    val effectiveHeight: Int? get() = if (resolution == ResolutionOption.CUSTOM) customHeight else resolution.height
    val effectiveFps: Int? get() = if (fps == FpsOption.CUSTOM) customFps else fps.fps

    companion object {
        fun forPreset(tier: QualityTier): ProcessingSettings = when (tier) {
            QualityTier.HIGH_QUALITY -> ProcessingSettings(
                preset = QualityTier.HIGH_QUALITY,
                resolution = ResolutionOption.ORIGINAL,
                videoCodec = VideoCodecOption.H264,
                videoBitrateBps = 16_000_000,
                audioBitrateBps = 192_000
            )
            QualityTier.BALANCED -> ProcessingSettings(
                preset = QualityTier.BALANCED,
                resolution = ResolutionOption.FHD_1080,
                videoCodec = VideoCodecOption.H264,
                videoBitrateBps = 6_000_000,
                audioBitrateBps = 128_000
            )
            QualityTier.SMALL_FILE -> ProcessingSettings(
                preset = QualityTier.SMALL_FILE,
                resolution = ResolutionOption.HD_720,
                videoCodec = VideoCodecOption.H265,
                videoBitrateBps = 2_000_000,
                audioBitrateBps = 96_000
            )
            QualityTier.CUSTOM -> ProcessingSettings(preset = QualityTier.CUSTOM)
        }
    }
}

enum class ProcessingStage(val label: String) {
    QUEUED("Queued"),
    ANALYZING_SOURCE("Analyzing source"),
    ENCODING("Encoding video"),
    MUXING("Finalizing file"),
    ANALYZING_OUTPUT("Checking result"),
    DONE("Done"),
    FAILED("Failed"),
    CANCELLED("Cancelled")
}

data class QualityWarning(val message: String, val isSevere: Boolean)

data class ProcessingResult(
    val outputUri: Uri,
    val outputMetadata: VideoMetadata
)

/** One item in the batch queue, from selection through to a finished (or failed) result. */
data class ProcessingJob(
    val id: String,
    val inputUri: Uri,
    val inputDisplayName: String,
    val settings: ProcessingSettings,
    val sourceMetadata: VideoMetadata? = null,
    val stage: ProcessingStage = ProcessingStage.QUEUED,
    val progressPercent: Int = 0,
    val warnings: List<QualityWarning> = emptyList(),
    val result: ProcessingResult? = null,
    val errorMessage: String? = null
) {
    val isFinished: Boolean get() = stage == ProcessingStage.DONE || stage == ProcessingStage.FAILED || stage == ProcessingStage.CANCELLED
}
