package com.variaflow.mobile.media

import com.variaflow.mobile.data.ProcessingSettings
import com.variaflow.mobile.data.QualityWarning
import com.variaflow.mobile.data.VideoMetadata

/**
 * Looks at the chosen [ProcessingSettings] against the source video and flags anything
 * likely to hurt visible quality *before* the user spends time processing — spec section 6:
 * "If processing settings are likely to cause significant quality loss, warn the user."
 *
 * These are heuristics, not guarantees — real encoded quality also depends on scene
 * complexity and the specific hardware encoder, which this app can't know in advance.
 */
object QualityAdvisor {

    fun evaluate(source: VideoMetadata, settings: ProcessingSettings): List<QualityWarning> {
        val warnings = mutableListOf<QualityWarning>()

        val targetWidth = settings.effectiveWidth ?: source.width
        val targetHeight = settings.effectiveHeight ?: source.height
        val targetPixels = targetWidth.toLong() * targetHeight
        val sourcePixels = source.width.toLong() * source.height

        if (sourcePixels > 0 && targetPixels > sourcePixels) {
            warnings += QualityWarning(
                "Output resolution (${targetWidth}×$targetHeight) is higher than the source " +
                    "(${source.width}×${source.height}). Upscaling won't add real detail — it just " +
                    "makes the file bigger.",
                isSevere = false
            )
        }

        // Rough "reasonable bitrate for this many pixels" floor, loosely based on typical
        // H.264 1080p30 web-video bitrates (~5 Mbps) scaled by pixel count.
        if (targetPixels > 0) {
            val referenceBitrateFor1080p30 = 5_000_000.0
            val referencePixels = 1920.0 * 1080.0
            val expectedMinimum = (referenceBitrateFor1080p30 * (targetPixels / referencePixels) * 0.35)
                .coerceAtLeast(400_000.0)
            if (settings.videoBitrateBps < expectedMinimum) {
                warnings += QualityWarning(
                    "The selected video bitrate is quite low for ${targetWidth}×$targetHeight and may " +
                        "show visible blocking or blur, especially in fast motion.",
                    isSevere = settings.videoBitrateBps < expectedMinimum * 0.5
                )
            }
        }

        if (source.bitrateBps > 0 && settings.videoBitrateBps > source.bitrateBps * 3) {
            warnings += QualityWarning(
                "The selected bitrate is much higher than the source's original bitrate — this will " +
                    "make the file larger without improving quality beyond the source.",
                isSevere = false
            )
        }

        val sourceFps = source.frameRate
        val targetFps = settings.effectiveFps
        if (targetFps != null && sourceFps > 0 && targetFps > sourceFps + 1) {
            warnings += QualityWarning(
                "Target frame rate ($targetFps fps) is higher than the source ($sourceFps fps). " +
                    "VariaFlow can't invent frames that weren't captured, so motion won't actually get smoother.",
                isSevere = false
            )
        }

        if (settings.audioSampleRateHz > 0 && source.audioSampleRateHz != null &&
            settings.audioSampleRateHz > source.audioSampleRateHz!!
        ) {
            warnings += QualityWarning(
                "Output audio sample rate is higher than the source's — this won't improve audio quality.",
                isSevere = false
            )
        }

        return warnings
    }
}
