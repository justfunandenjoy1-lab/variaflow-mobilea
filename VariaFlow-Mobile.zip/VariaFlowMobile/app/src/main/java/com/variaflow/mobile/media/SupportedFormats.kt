package com.variaflow.mobile.media

import com.variaflow.mobile.data.InputContainer

/** Result of checking whether VariaFlow can actually open a picked file. */
sealed class FormatCheckResult {
    data class Supported(val container: InputContainer) : FormatCheckResult()
    data class Unsupported(val container: InputContainer, val reason: String) : FormatCheckResult()
}

/**
 * Checks a picked file's extension against what this build can actually decode.
 *
 * VariaFlow processes video entirely with Android's own MediaExtractor/MediaCodec
 * stack (via Media3 Transformer) — there is no bundled FFmpeg in this build, so
 * containers that Android's extractor can't demux (AVI, and any file with the
 * wrong extension) are rejected here with a clear reason instead of failing
 * confusingly later during processing.
 */
object SupportedFormats {

    fun check(displayName: String): FormatCheckResult {
        val container = InputContainer.fromFileName(displayName)
        return when {
            container == InputContainer.UNKNOWN -> FormatCheckResult.Unsupported(
                container,
                "\"$displayName\" doesn't look like a video VariaFlow recognizes. " +
                    "Supported types: MP4, MOV, MKV, WEBM."
            )
            !container.nativelySupported -> FormatCheckResult.Unsupported(
                container,
                "${container.label} files aren't supported in this build. Android's on-device " +
                    "decoder can't open AVI containers without an additional FFmpeg component, " +
                    "which isn't bundled here — see the README. Try converting the file to MP4 first."
            )
            else -> FormatCheckResult.Supported(container)
        }
    }
}
