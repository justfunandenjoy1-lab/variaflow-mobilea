package com.variaflow.mobile.media

import android.content.Context
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import com.variaflow.mobile.data.InputContainer
import com.variaflow.mobile.data.VideoMetadata

/**
 * Reads container, codec, resolution, frame-rate, bitrate, and audio-track
 * details straight off the device. Nothing here is uploaded anywhere — it's
 * the same MediaExtractor / MediaMetadataRetriever APIs any local Android
 * app uses to inspect a file it already has a Uri for.
 */
object VideoInfoExtractor {

    fun extract(context: Context, uri: Uri, displayName: String): VideoMetadata {
        val fileSize = queryFileSize(context, uri)
        val container = InputContainer.fromFileName(displayName)

        var durationMs = 0L
        var rotation = 0
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull() ?: 0L
            rotation = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)
                ?.toIntOrNull() ?: 0
        } catch (_: Exception) {
            // Fall through with duration/rotation left at their defaults; the track-level
            // read below is what really matters for the fields shown on screen.
        } finally {
            retriever.release()
        }

        var width = 0
        var height = 0
        var frameRate = 0f
        var videoCodecLabel = "Unknown"
        var audioCodecLabel: String? = null
        var videoBitrate = 0L
        var audioBitrate = 0L
        var sampleRate: Int? = null
        var channelCount: Int? = null

        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(context, uri, null)
            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: continue
                when {
                    mime.startsWith("video/") -> {
                        width = format.safeInt(MediaFormat.KEY_WIDTH) ?: 0
                        height = format.safeInt(MediaFormat.KEY_HEIGHT) ?: 0
                        frameRate = format.safeFloat(MediaFormat.KEY_FRAME_RATE) ?: 0f
                        videoBitrate = (format.safeInt(MediaFormat.KEY_BIT_RATE) ?: 0).toLong()
                        videoCodecLabel = CodecNames.forMime(mime)
                    }
                    mime.startsWith("audio/") -> {
                        sampleRate = format.safeInt(MediaFormat.KEY_SAMPLE_RATE)
                        channelCount = format.safeInt(MediaFormat.KEY_CHANNEL_COUNT)
                        audioBitrate = (format.safeInt(MediaFormat.KEY_BIT_RATE) ?: 0).toLong()
                        audioCodecLabel = CodecNames.forMime(mime)
                    }
                }
            }
        } catch (_: Exception) {
            // Best-effort: SupportedFormats.check() already gated obviously-unsupported
            // containers before this point, so a failure here just leaves some fields blank
            // rather than crashing the info screen.
        } finally {
            extractor.release()
        }

        // Some devices report a rotated video's width/height in landscape terms even
        // though it plays back in portrait — swap so what we show matches what's on screen.
        if (rotation == 90 || rotation == 270) {
            val swap = width
            width = height
            height = swap
        }

        val totalBitrate = when {
            videoBitrate > 0 -> videoBitrate + audioBitrate
            fileSize > 0 && durationMs > 0 -> fileSize * 8_000L / durationMs
            else -> 0L
        }

        return VideoMetadata(
            displayName = displayName,
            uri = uri,
            fileSizeBytes = fileSize,
            durationMs = durationMs,
            width = width,
            height = height,
            frameRate = frameRate,
            videoCodec = videoCodecLabel,
            audioCodec = audioCodecLabel,
            bitrateBps = totalBitrate,
            containerLabel = container.label,
            audioSampleRateHz = sampleRate,
            audioChannelCount = channelCount
        )
    }

    private fun queryFileSize(context: Context, uri: Uri): Long {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)
            ?.use { cursor ->
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (sizeIndex != -1 && cursor.moveToFirst() && !cursor.isNull(sizeIndex)) {
                    return cursor.getLong(sizeIndex)
                }
            }
        return 0L
    }

    private fun MediaFormat.safeInt(key: String): Int? =
        if (containsKey(key)) {
            try {
                getInteger(key)
            } catch (_: Exception) {
                null
            }
        } else null

    private fun MediaFormat.safeFloat(key: String): Float? =
        if (containsKey(key)) {
            try {
                getFloat(key)
            } catch (_: Exception) {
                safeInt(key)?.toFloat()
            }
        } else null
}

/** Friendly names for the MIME types MediaFormat reports, used throughout the UI. */
object CodecNames {
    fun forMime(mime: String): String = when (mime) {
        "video/avc" -> "H.264 (AVC)"
        "video/hevc" -> "H.265 (HEVC)"
        "video/x-vnd.on2.vp8" -> "VP8"
        "video/x-vnd.on2.vp9" -> "VP9"
        "video/av01" -> "AV1"
        "video/mp4v-es" -> "MPEG-4"
        "audio/mp4a-latm" -> "AAC"
        "audio/vorbis" -> "Vorbis"
        "audio/opus" -> "Opus"
        "audio/raw" -> "PCM"
        "audio/ac3" -> "AC-3"
        "audio/eac3" -> "E-AC-3"
        else -> mime
    }
}
