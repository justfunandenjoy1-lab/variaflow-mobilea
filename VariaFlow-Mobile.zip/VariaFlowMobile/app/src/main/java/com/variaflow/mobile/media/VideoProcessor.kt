package com.variaflow.mobile.media

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import com.variaflow.mobile.data.ProcessingSettings
import com.variaflow.mobile.data.VideoCodecOption
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Thin wrapper around Media3's [Transformer] — the on-device decode → filter → encode → mux
 * pipeline this app uses instead of bundling a native FFmpeg build. Everything here runs
 * entirely on-device: [Transformer] reads the source through Android's own MediaExtractor /
 * MediaCodec stack and writes straight to a local file, with nothing sent over the network.
 *
 * One instance is created per job so [cancel] can target the exact [Transformer] that job
 * is running on, without touching any other job in a batch.
 */
class VideoProcessor {

    private val mainHandler = Handler(Looper.getMainLooper())

    @Volatile
    private var transformer: Transformer? = null

    @Volatile
    private var cancelRequested = false

    data class Outcome(val success: Boolean, val exportException: ExportException?)

    /**
     * Runs the export and suspends until it finishes, fails, or is cancelled, polling
     * [Transformer.getProgress] roughly every 300ms since Transformer only reports progress
     * on demand rather than as a stream. Must be started fresh per job — this instance is
     * single-use.
     */
    suspend fun process(
        context: Context,
        inputUri: Uri,
        outputFile: File,
        settings: ProcessingSettings,
        onProgress: (Int) -> Unit
    ): Outcome = withContext(Dispatchers.Main) {
        if (cancelRequested) return@withContext Outcome(false, null)

        val completion = CompletableDeferred<Outcome>()

        val encoderSettings = VideoEncoderSettings.Builder()
            .setBitrate(settings.videoBitrateBps)
            .build()
        val encoderFactory = DefaultEncoderFactory.Builder(context.applicationContext)
            .setRequestedVideoEncoderSettings(encoderSettings)
            .build()

        val videoMimeType = when (settings.videoCodec) {
            VideoCodecOption.H264 -> MimeTypes.VIDEO_H264
            VideoCodecOption.H265 -> MimeTypes.VIDEO_H265
        }

        val builtTransformer = Transformer.Builder(context.applicationContext)
            .setVideoMimeType(videoMimeType)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .setEncoderFactory(encoderFactory)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    completion.complete(Outcome(true, null))
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    completion.complete(Outcome(false, exportException))
                }
            })
            .build()
        transformer = builtTransformer

        val videoEffects = mutableListOf<Effect>()
        val targetWidth = settings.effectiveWidth
        val targetHeight = settings.effectiveHeight
        if (targetWidth != null && targetHeight != null) {
            videoEffects += Presentation.createForWidthAndHeight(
                targetWidth,
                targetHeight,
                Presentation.LAYOUT_SCALE_TO_FIT
            )
        }
        // Frame-rate note: Transformer (media3-transformer 1.10.x) encodes at the source's
        // frame rate — there is no supported "target output fps" knob on EditedMediaItem/
        // Transformer.Builder as of this version. The FPS choice in ProcessingSettings is
        // therefore surfaced to the user as a QualityAdvisor warning when it wouldn't
        // actually be honored, rather than silently ignored. Revisit if a future Media3
        // release adds real frame-rate conversion support.

        val editedMediaItem = EditedMediaItem.Builder(MediaItem.fromUri(inputUri))
            .setEffects(Effects(/* audioProcessors = */ emptyList(), videoEffects))
            .build()

        if (cancelRequested) {
            return@withContext Outcome(false, null)
        }

        builtTransformer.start(editedMediaItem, outputFile.absolutePath)

        val progressHolder = ProgressHolder()
        while (isActive && !completion.isCompleted) {
            val state = builtTransformer.getProgress(progressHolder)
            if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                onProgress(progressHolder.progress)
            }
            delay(300)
        }

        completion.await()
    }

    /** Safe to call from any thread; the actual [Transformer.cancel] hop happens on the main looper. */
    fun cancel() {
        cancelRequested = true
        mainHandler.post { transformer?.cancel() }
    }
}
