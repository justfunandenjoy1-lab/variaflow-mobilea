package com.variaflow.mobile.service

import com.variaflow.mobile.data.ProcessingJob
import com.variaflow.mobile.data.ProcessingStage
import com.variaflow.mobile.media.VideoProcessor
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update

/**
 * The single shared queue that [com.variaflow.mobile.viewmodel.MainViewModel] (UI side) and
 * [ProcessingService] (worker side) both read and write. VariaFlow is a single-process local
 * app, so a plain in-memory singleton is enough to hand work from the UI to the service and
 * progress back again — no IPC/Binder plumbing needed.
 */
object ProcessingRepository {

    private val _jobs = MutableStateFlow<List<ProcessingJob>>(emptyList())
    val jobs: StateFlow<List<ProcessingJob>> = _jobs

    /** Set by [ProcessingService] while a job is actively encoding, so [requestCancel] can reach it. */
    @Volatile var activeJobId: String? = null
    @Volatile var activeProcessor: VideoProcessor? = null

    fun enqueue(newJobs: List<ProcessingJob>) {
        _jobs.update { it + newJobs }
    }

    fun updateJob(id: String, transform: (ProcessingJob) -> ProcessingJob) {
        _jobs.update { list -> list.map { if (it.id == id) transform(it) else it } }
    }

    fun requestCancel(id: String) {
        val job = _jobs.value.firstOrNull { it.id == id } ?: return
        when {
            job.stage == ProcessingStage.QUEUED -> updateJob(id) {
                it.copy(stage = ProcessingStage.CANCELLED, errorMessage = null)
            }
            id == activeJobId -> {
                updateJob(id) { it.copy(stage = ProcessingStage.CANCELLED, errorMessage = null) }
                activeProcessor?.cancel()
            }
            // Already finished one way or another — nothing to do.
        }
    }

    fun removeJob(id: String) {
        _jobs.update { list -> list.filterNot { it.id == id } }
    }

    fun clearFinished() {
        _jobs.update { list -> list.filterNot { it.isFinished } }
    }

    fun hasQueuedWork(): Boolean = _jobs.value.any { it.stage == ProcessingStage.QUEUED }
}
