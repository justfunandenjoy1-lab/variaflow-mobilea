package com.variaflow.mobile.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import com.variaflow.mobile.MainActivity
import com.variaflow.mobile.R
import com.variaflow.mobile.data.ProcessingResult
import com.variaflow.mobile.data.ProcessingStage
import com.variaflow.mobile.media.QualityAdvisor
import com.variaflow.mobile.media.VideoInfoExtractor
import com.variaflow.mobile.media.VideoProcessor
import com.variaflow.mobile.storage.OutputFileManager
import com.variaflow.mobile.util.VariaFlowException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/**
 * Foreground service that owns the actual on-device transcode work (spec section 8/9: progress,
 * stages, batch queue) so a conversion keeps running even if the user leaves the app. It only
 * ever reads/writes [ProcessingRepository] — [com.variaflow.mobile.viewmodel.MainViewModel]
 * enqueues jobs there and this service drains them one at a time, in order.
 *
 * Declared in the manifest as foregroundServiceType="mediaProcessing" (Android 14+ requires a
 * matching type, and caps this type's continuous runtime at 6 hours per start — plenty for
 * on-device video conversion, but worth knowing if very large batches are ever queued).
 */
class ProcessingService : LifecycleService() {

    private var queueJob: Job? = null

    companion object {
        private const val CHANNEL_ID = "processing"
        private const val NOTIFICATION_ID = 42
        const val ACTION_PROCESS_QUEUE = "com.variaflow.mobile.action.PROCESS_QUEUE"

        /** Ensures the service is running and (re)checks the queue. Safe to call repeatedly. */
        fun kick(context: Context) {
            val intent = Intent(context, ProcessingService::class.java).setAction(ACTION_PROCESS_QUEUE)
            context.startForegroundService(intent)
        }
    }

    override fun onCreate() {
        super.onCreate()
        ensureChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        startForeground(NOTIFICATION_ID, buildNotification(getString(R.string.app_name), "Getting ready…", 0))
        if (queueJob?.isActive != true) {
            queueJob = lifecycleScope.launch { runQueue() }
        }
        return START_NOT_STICKY
    }

    private suspend fun runQueue() {
        while (true) {
            val next = ProcessingRepository.jobs.value.firstOrNull { it.stage == ProcessingStage.QUEUED } ?: break
            runOne(next.id)
        }
        stopForegroundCompat()
        stopSelf()
    }

    private suspend fun runOne(jobId: String) {
        val job = ProcessingRepository.jobs.value.find { it.id == jobId } ?: return
        ProcessingRepository.activeJobId = jobId

        try {
            ProcessingRepository.updateJob(jobId) { it.copy(stage = ProcessingStage.ANALYZING_SOURCE, progressPercent = 0) }
            updateNotification(job.inputDisplayName, "Analyzing source", 0)

            val source = job.sourceMetadata ?: VideoInfoExtractor.extract(this, job.inputUri, job.inputDisplayName)
            val warnings = QualityAdvisor.evaluate(source, job.settings)
            ProcessingRepository.updateJob(jobId) {
                it.copy(sourceMetadata = source, warnings = warnings, stage = ProcessingStage.ENCODING)
            }

            if (!OutputFileManager.hasEnoughFreeSpace()) throw VariaFlowException.InsufficientStorage()

            val processor = VideoProcessor()
            ProcessingRepository.activeProcessor = processor
            val scratch = OutputFileManager.createScratchFile(this, job.settings.outputContainer)

            updateNotification(job.inputDisplayName, "Encoding video", 0)
            val outcome = processor.process(this, job.inputUri, scratch, job.settings) { percent ->
                ProcessingRepository.updateJob(jobId) { it.copy(progressPercent = percent) }
                updateNotification(job.inputDisplayName, "Encoding video", percent)
            }
            ProcessingRepository.activeProcessor = null

            val stillCancelled = ProcessingRepository.jobs.value.find { it.id == jobId }?.stage == ProcessingStage.CANCELLED
            if (stillCancelled) {
                scratch.delete()
                return
            }

            if (!outcome.success) {
                scratch.delete()
                val friendly = outcome.exportException?.let { VariaFlowException.from(it, job.inputDisplayName) }
                    ?: VariaFlowException.Unknown("export did not complete")
                ProcessingRepository.updateJob(jobId) { it.copy(stage = ProcessingStage.FAILED, errorMessage = friendly.message) }
                return
            }

            ProcessingRepository.updateJob(jobId) { it.copy(stage = ProcessingStage.ANALYZING_OUTPUT, progressPercent = 100) }
            updateNotification(job.inputDisplayName, "Checking result", 100)

            val displayName = OutputFileManager.nextDisplayName(this, job.inputDisplayName, job.settings.outputContainer)
            val outputUri = OutputFileManager.publish(this, scratch, displayName, job.settings.outputContainer)
            val outputMetadata = VideoInfoExtractor.extract(this, outputUri, displayName)

            ProcessingRepository.updateJob(jobId) {
                it.copy(
                    stage = ProcessingStage.DONE,
                    progressPercent = 100,
                    result = ProcessingResult(outputUri, outputMetadata)
                )
            }
        } catch (t: Throwable) {
            val friendly = VariaFlowException.from(t, job.inputDisplayName)
            ProcessingRepository.updateJob(jobId) { it.copy(stage = ProcessingStage.FAILED, errorMessage = friendly.message) }
        } finally {
            ProcessingRepository.activeProcessor = null
            ProcessingRepository.activeJobId = null
        }
    }

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            if (manager.getNotificationChannel(CHANNEL_ID) == null) {
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    getString(R.string.notification_channel_name),
                    NotificationManager.IMPORTANCE_LOW
                ).apply { description = getString(R.string.notification_channel_description) }
                manager.createNotificationChannel(channel)
            }
        }
    }

    private fun buildNotification(title: String, status: String, percent: Int): Notification {
        val openApp = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(status)
            // TODO: swap for a branded monochrome notification icon before shipping.
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setProgress(100, percent, false)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openApp)
            .build()
    }

    private fun updateNotification(fileName: String, stage: String, percent: Int) {
        val manager = getSystemService(NotificationManager::class.java) ?: return
        manager.notify(NOTIFICATION_ID, buildNotification(fileName, "$stage — $percent%", percent))
    }

    private fun stopForegroundCompat() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            @Suppress("DEPRECATION")
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
    }
}
