package com.variaflow.mobile.storage

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.variaflow.mobile.data.OutputContainer
import java.io.File
import java.io.IOException

/**
 * Owns everything about *where processed videos end up*: a scratch file for Transformer to
 * write to (it needs a local file path, not a content Uri), unique output naming
 * (spec section 10: "Use unique filenames so existing files are not accidentally
 * overwritten"), and publishing the result into the shared Movies/VariaFlow/Output
 * collection through MediaStore — the scoped-storage-correct way to save a video that
 * survives the app being uninstalled and needs no storage permission on Android 10+.
 */
object OutputFileManager {

    private const val RELATIVE_FOLDER = "Movies/VariaFlow/Output"

    /** A private scratch location for Transformer's own output before it's published. */
    fun createScratchFile(context: Context, container: OutputContainer): File {
        val dir = File(context.cacheDir, "variaflow_tmp").apply { mkdirs() }
        val name = "scratch_${System.currentTimeMillis()}_${(0..9999).random()}.${container.extension}"
        return File(dir, name)
    }

    /**
     * Picks the next "video_NNN_processed.ext" name that isn't already used in the output
     * collection, starting from 001 and counting up — matches the naming spec's example
     * ("video_001_processed.mp4") while guaranteeing no collision.
     */
    fun nextDisplayName(context: Context, sourceBaseName: String, container: OutputContainer): String {
        val safeBase = sourceBaseName
            .substringBeforeLast('.')
            .replace(Regex("[^A-Za-z0-9_-]"), "_")
            .take(40)
            .ifBlank { "video" }

        val existing = existingDisplayNames(context)
        var index = 1
        while (true) {
            val candidate = "${safeBase}_%03d_processed.${container.extension}".format(index)
            if (candidate !in existing) return candidate
            index++
        }
    }

    private fun existingDisplayNames(context: Context): Set<String> {
        val names = mutableSetOf<String>()
        val projection = arrayOf(MediaStore.Video.Media.DISPLAY_NAME)
        val selection = "${MediaStore.Video.Media.RELATIVE_PATH} = ?"
        val args = arrayOf("$RELATIVE_FOLDER/")
        try {
            context.contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                projection,
                selection,
                args,
                null
            )?.use { cursor ->
                val nameIndex = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                while (cursor.moveToNext()) {
                    names += cursor.getString(nameIndex)
                }
            }
        } catch (_: Exception) {
            // If the query fails for any reason, we fall back to timestamp-style collision
            // avoidance being unnecessary — the counter loop above still works, it just might
            // start from 001 again on a device that can't answer this query, in which case
            // MediaStore.insert below will itself de-duplicate the filename for us.
        }
        return names
    }

    /**
     * Copies [scratchFile] into the shared Movies/VariaFlow/Output collection and deletes the
     * scratch copy. Returns the new file's content Uri.
     */
    @Throws(IOException::class)
    fun publish(context: Context, scratchFile: File, displayName: String, container: OutputContainer): Uri {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
            put(MediaStore.Video.Media.MIME_TYPE, mimeTypeFor(container))
            put(MediaStore.Video.Media.RELATIVE_PATH, RELATIVE_FOLDER)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
        }

        val collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val itemUri = resolver.insert(collection, values)
            ?: throw IOException("MediaStore refused to create an entry for the output video.")

        try {
            resolver.openOutputStream(itemUri)?.use { out ->
                scratchFile.inputStream().use { input -> input.copyTo(out) }
            } ?: throw IOException("Couldn't open an output stream for the saved video.")

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                values.clear()
                values.put(MediaStore.Video.Media.IS_PENDING, 0)
                resolver.update(itemUri, values, null, null)
            }
        } catch (e: IOException) {
            resolver.delete(itemUri, null, null)
            throw e
        } finally {
            scratchFile.delete()
        }

        return itemUri
    }

    /** Only MP4 is actually produced by this build (see OutputContainer.supported), but this stays exhaustive. */
    private fun mimeTypeFor(container: OutputContainer): String = when (container) {
        OutputContainer.MP4 -> "video/mp4"
        OutputContainer.MOV -> "video/quicktime"
        OutputContainer.MKV -> "video/x-matroska"
    }

    /** Opens (plays) a single processed video directly — the one "Open Output" path that's reliable on every device. */
    fun viewIntent(uri: Uri): Intent = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(uri, "video/*")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }

    /**
     * Best-effort attempt to open the Movies/VariaFlow/Output *folder* itself in whatever
     * document/file browser the device has. Folder-browsing intents aren't standardized
     * across OEMs the way opening a single file is, so callers should fall back to
     * [viewIntent] on the most recent output if this doesn't resolve to anything.
     */
    fun openFolderIntent(): Intent = Intent(Intent.ACTION_VIEW).apply {
        val docsUri = Uri.parse(
            "content://com.android.externalstorage.documents/document/primary%3A" +
                Uri.encode(RELATIVE_FOLDER, "/").replace("/", "%2F")
        )
        setDataAndType(docsUri, "vnd.android.document/directory")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    /** Human-facing label for where output lives, shown on the Home screen. */
    fun outputFolderLabel(): String = "Movies/VariaFlow/Output"

    fun hasEnoughFreeSpace(minimumBytes: Long = 200L * 1024 * 1024): Boolean {
        return try {
            val stat = Environment.getExternalStorageDirectory()
            val usable = stat.usableSpace
            usable >= minimumBytes
        } catch (_: Exception) {
            true // Fail open — a real write failure will still surface a clear InsufficientStorage error.
        }
    }
}
