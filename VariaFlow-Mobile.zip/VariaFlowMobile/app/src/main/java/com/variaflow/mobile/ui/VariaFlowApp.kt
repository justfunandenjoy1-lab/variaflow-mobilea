package com.variaflow.mobile.ui

import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.variaflow.mobile.ui.navigation.AppScreen
import com.variaflow.mobile.ui.screens.ComparisonScreen
import com.variaflow.mobile.ui.screens.HomeScreen
import com.variaflow.mobile.viewmodel.MainViewModel
import kotlinx.coroutines.flow.collectLatest

/** Root composable: wires [MainViewModel] state to [HomeScreen] / [ComparisonScreen]. */
@Composable
fun VariaFlowApp(
    viewModel: MainViewModel,
    onPickVideos: () -> Unit,
    onPlayVideo: (android.net.Uri) -> Unit,
    onOpenOutputFolder: () -> Unit,
    modifier: Modifier = Modifier
) {
    val stagedVideos by viewModel.stagedVideos.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val jobs by viewModel.jobs.collectAsStateWithLifecycle()
    val settingsSheetOpen by viewModel.settingsSheetOpen.collectAsStateWithLifecycle()
    val comparisonJobId by viewModel.comparisonJobId.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(Unit) {
        viewModel.events.collectLatest { message -> snackbarHostState.showSnackbar(message) }
    }

    val screen = comparisonJobId?.let { id -> jobs.find { it.id == id } }?.let { AppScreen.Comparison(it.id) } ?: AppScreen.Home

    when (screen) {
        is AppScreen.Home -> HomeScreen(
            stagedVideos = stagedVideos,
            settings = settings,
            jobs = jobs,
            settingsSheetOpen = settingsSheetOpen,
            outputFolderLabel = viewModel.outputFolderLabel,
            snackbarHostState = snackbarHostState,
            onPickVideos = onPickVideos,
            onRemoveStaged = viewModel::removeStagedVideo,
            onSelectPreset = viewModel::selectPreset,
            onOpenSettings = viewModel::openSettingsSheet,
            onCloseSettings = viewModel::closeSettingsSheet,
            onUpdateSettings = viewModel::updateSettings,
            onStartProcessing = viewModel::startProcessing,
            onCancelJob = viewModel::cancelJob,
            onViewComparison = viewModel::showComparison,
            onDismissJob = viewModel::removeFinishedJob,
            onOpenOutput = onOpenOutputFolder,
            modifier = modifier
        )
        is AppScreen.Comparison -> {
            val job = jobs.find { it.id == screen.jobId }
            if (job != null) {
                ComparisonScreen(
                    job = job,
                    onBack = viewModel::closeComparison,
                    onPlayOutput = { job.result?.outputUri?.let(onPlayVideo) },
                    modifier = modifier
                )
            }
        }
    }
}
