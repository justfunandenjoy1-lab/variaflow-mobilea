package com.variaflow.mobile.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.variaflow.mobile.R
import com.variaflow.mobile.data.ProcessingJob
import com.variaflow.mobile.data.ProcessingStage

/**
 * Spec sections 8 & 9: per-item progress/stage during processing, plus batch summary
 * (current file, completed, failed, remaining) shown just above the list.
 */
@Composable
fun BatchSummary(jobs: List<ProcessingJob>, modifier: Modifier = Modifier) {
    val completed = jobs.count { it.stage == ProcessingStage.DONE }
    val failed = jobs.count { it.stage == ProcessingStage.FAILED }
    val remaining = jobs.count { it.stage == ProcessingStage.QUEUED }
    val current = jobs.firstOrNull { it.stage != ProcessingStage.QUEUED && !it.isFinished }

    Column(modifier.fillMaxWidth()) {
        if (current != null) {
            Text(
                "Processing: ${current.inputDisplayName}",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Medium
            )
        }
        Text(
            "$completed done • $failed failed • $remaining remaining",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun JobRow(
    job: ProcessingJob,
    onCancel: () -> Unit,
    onViewComparison: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(job.inputDisplayName, style = MaterialTheme.typography.bodyLarge, maxLines = 1, modifier = Modifier.weight(1f))
                StatusIcon(job.stage)
            }
            Text(
                job.errorMessage ?: job.stage.label,
                style = MaterialTheme.typography.bodyMedium,
                color = if (job.stage == ProcessingStage.FAILED) MaterialTheme.colorScheme.error
                else MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (!job.isFinished) {
                LinearProgressIndicator(
                    progress = { job.progressPercent / 100f },
                    modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
                )
                Text("${job.progressPercent}%", style = MaterialTheme.typography.labelMedium)
            }
            Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                when (job.stage) {
                    ProcessingStage.DONE -> TextButton(onClick = onViewComparison) { Text("View result") }
                    ProcessingStage.FAILED, ProcessingStage.CANCELLED -> TextButton(onClick = onDismiss) { Text("Dismiss") }
                    else -> IconButton(onClick = onCancel) {
                        Icon(Icons.Filled.Close, contentDescription = stringResource(R.string.cd_cancel))
                    }
                }
            }
        }
    }
}

@Composable
private fun StatusIcon(stage: ProcessingStage) {
    when (stage) {
        ProcessingStage.DONE -> Icon(
            Icons.Filled.CheckCircle,
            contentDescription = stringResource(R.string.cd_success),
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(20.dp)
        )
        ProcessingStage.FAILED -> Icon(
            Icons.Filled.ErrorOutline,
            contentDescription = stringResource(R.string.cd_failed),
            tint = MaterialTheme.colorScheme.error,
            modifier = Modifier.size(20.dp)
        )
        else -> {}
    }
}
