package com.variaflow.mobile.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.variaflow.mobile.data.VideoMetadata
import com.variaflow.mobile.util.FormatUtils

/** Spec section 7's before/after comparison table: Original vs Output, metric by metric. */
@Composable
fun ComparisonCard(original: VideoMetadata, output: VideoMetadata, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Row(Modifier.fillMaxWidth()) {
                Text("", modifier = Modifier.weight(1f))
                Text(
                    "Original", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    "Output", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f)
                )
            }
            ComparisonRow("Resolution", FormatUtils.resolution(original.width, original.height), FormatUtils.resolution(output.width, output.height))
            ComparisonRow("Frame rate", FormatUtils.fps(original.frameRate), FormatUtils.fps(output.frameRate))
            ComparisonRow("Bitrate", FormatUtils.bitrate(original.bitrateBps), FormatUtils.bitrate(output.bitrateBps))
            ComparisonRow(
                "Size",
                FormatUtils.fileSize(original.fileSizeBytes),
                "${FormatUtils.fileSize(output.fileSizeBytes)} (${FormatUtils.percentChange(original.fileSizeBytes, output.fileSizeBytes)})"
            )
            ComparisonRow("Codec", original.videoCodec, output.videoCodec)
            ComparisonRow("Container", original.containerLabel, output.containerLabel)
        }
    }
}

@Composable
private fun ComparisonRow(label: String, originalValue: String, outputValue: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
        Text(originalValue, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Text(outputValue, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
    }
}
