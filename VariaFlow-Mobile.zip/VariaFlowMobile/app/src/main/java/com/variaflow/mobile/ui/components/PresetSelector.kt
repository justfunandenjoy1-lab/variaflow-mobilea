package com.variaflow.mobile.ui.components

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.variaflow.mobile.data.QualityTier

/** The four presets from spec section 4 — High Quality, Balanced, Small File, Custom. */
@Composable
fun PresetSelector(
    selected: QualityTier,
    onSelect: (QualityTier) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.horizontalScroll(rememberScrollState()).padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        QualityTier.entries.forEach { tier ->
            FilterChip(
                selected = tier == selected,
                onClick = { onSelect(tier) },
                label = { Text(tier.label) },
                colors = FilterChipDefaults.filterChipColors()
            )
        }
    }
}
