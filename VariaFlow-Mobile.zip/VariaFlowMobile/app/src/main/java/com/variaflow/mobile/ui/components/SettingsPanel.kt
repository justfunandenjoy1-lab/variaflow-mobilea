package com.variaflow.mobile.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.variaflow.mobile.data.AudioCodecOption
import com.variaflow.mobile.data.FpsOption
import com.variaflow.mobile.data.OutputContainer
import com.variaflow.mobile.data.ProcessingSettings
import com.variaflow.mobile.data.ResolutionOption
import com.variaflow.mobile.data.VideoCodecOption
import com.variaflow.mobile.util.FormatUtils

/**
 * The Custom preset's full settings form (spec section 4): output container, resolution,
 * fps, video codec + bitrate, and audio codec + bitrate/sample rate/channels.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsPanel(
    settings: ProcessingSettings,
    onChange: ((ProcessingSettings) -> ProcessingSettings) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        Text("Custom settings", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)

        SectionLabel("Container")
        EnumDropdown(
            label = "Output container",
            options = OutputContainer.entries,
            selected = settings.outputContainer,
            optionLabel = { if (it.supported) it.label else "${it.label} (not supported in this build)" },
            onSelect = { chosen ->
                if (chosen.supported) onChange { it.copy(outputContainer = chosen) }
            }
        )

        HorizontalDivider()
        SectionLabel("Video")
        EnumDropdown(
            label = "Resolution",
            options = ResolutionOption.entries,
            selected = settings.resolution,
            optionLabel = { it.label },
            onSelect = { chosen -> onChange { it.copy(resolution = chosen) } }
        )
        if (settings.resolution == ResolutionOption.CUSTOM) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                NumberField(
                    label = "Width",
                    value = settings.customWidth,
                    onValue = { onChange { s -> s.copy(customWidth = it) } },
                    modifier = Modifier.weight(1f)
                )
                NumberField(
                    label = "Height",
                    value = settings.customHeight,
                    onValue = { onChange { s -> s.copy(customHeight = it) } },
                    modifier = Modifier.weight(1f)
                )
            }
        }
        EnumDropdown(
            label = "Frame rate",
            options = FpsOption.entries,
            selected = settings.fps,
            optionLabel = { it.label },
            onSelect = { chosen -> onChange { it.copy(fps = chosen) } }
        )
        if (settings.fps == FpsOption.CUSTOM) {
            NumberField(
                label = "Custom fps",
                value = settings.customFps,
                onValue = { onChange { s -> s.copy(customFps = it) } }
            )
        }
        EnumDropdown(
            label = "Video codec",
            options = VideoCodecOption.entries,
            selected = settings.videoCodec,
            optionLabel = { it.label },
            onSelect = { chosen -> onChange { it.copy(videoCodec = chosen) } }
        )
        BitrateSlider(
            label = "Video bitrate",
            valueBps = settings.videoBitrateBps,
            range = 500_000f..30_000_000f,
            onValue = { onChange { s -> s.copy(videoBitrateBps = it) } }
        )

        HorizontalDivider()
        SectionLabel("Audio")
        EnumDropdown(
            label = "Audio codec",
            options = AudioCodecOption.entries,
            selected = settings.audioCodec,
            optionLabel = { it.label },
            onSelect = { chosen -> onChange { it.copy(audioCodec = chosen) } }
        )
        BitrateSlider(
            label = "Audio bitrate",
            valueBps = settings.audioBitrateBps,
            range = 32_000f..320_000f,
            onValue = { onChange { s -> s.copy(audioBitrateBps = it) } }
        )
        EnumDropdown(
            label = "Sample rate",
            options = listOf(44_100, 48_000),
            selected = settings.audioSampleRateHz,
            optionLabel = { "${it / 1000} kHz" },
            onSelect = { chosen -> onChange { it.copy(audioSampleRateHz = chosen) } }
        )
        EnumDropdown(
            label = "Channels",
            options = listOf(1, 2),
            selected = settings.audioChannelCount,
            optionLabel = { FormatUtils.channelLabel(it) },
            onSelect = { chosen -> onChange { it.copy(audioChannelCount = chosen) } }
        )
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(text, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun <T> EnumDropdown(
    label: String,
    options: List<T>,
    selected: T,
    optionLabel: (T) -> String,
    onSelect: (T) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
        OutlinedTextField(
            readOnly = true,
            value = optionLabel(selected),
            onValueChange = {},
            label = { Text(label) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier.fillMaxWidth().menuAnchor()
        )
        androidx.compose.material3.ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { option ->
                DropdownMenuItem(
                    text = { Text(optionLabel(option)) },
                    onClick = {
                        onSelect(option)
                        expanded = false
                    }
                )
            }
        }
    }
}

@Composable
private fun NumberField(label: String, value: Int?, onValue: (Int?) -> Unit, modifier: Modifier = Modifier) {
    OutlinedTextField(
        value = value?.toString() ?: "",
        onValueChange = { text -> onValue(text.filter { it.isDigit() }.toIntOrNull()) },
        label = { Text(label) },
        singleLine = true,
        modifier = modifier.fillMaxWidth()
    )
}

@Composable
private fun BitrateSlider(label: String, valueBps: Int, range: ClosedFloatingPointRange<Float>, onValue: (Int) -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, style = MaterialTheme.typography.bodyMedium)
            Text(FormatUtils.bitrate(valueBps.toLong()), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
        }
        Slider(
            value = valueBps.toFloat().coerceIn(range),
            valueRange = range,
            onValueChange = { onValue(it.toInt()) }
        )
    }
}
