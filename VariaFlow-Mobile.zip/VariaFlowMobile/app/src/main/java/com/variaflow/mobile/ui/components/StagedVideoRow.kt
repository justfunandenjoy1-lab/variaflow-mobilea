package com.variaflow.mobile.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.variaflow.mobile.R
import com.variaflow.mobile.util.FormatUtils
import com.variaflow.mobile.viewmodel.StagedVideo

/** One row per picked-but-not-yet-queued video on the Home screen. */
@Composable
fun StagedVideoRow(video: StagedVideo, onRemove: () -> Unit, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(
                imageVector = Icons.Filled.Movie,
                contentDescription = stringResource(R.string.cd_video_thumbnail),
                tint = MaterialTheme.colorScheme.primary
            )
            Column(Modifier.weight(1f)) {
                Text(video.displayName, style = MaterialTheme.typography.bodyLarge, maxLines = 1)
                val subtitle = when {
                    video.unsupportedReason != null -> video.unsupportedReason
                    video.isLoadingMetadata -> "Reading video info…"
                    video.metadata != null -> "${FormatUtils.resolution(video.metadata.width, video.metadata.height)} • " +
                        "${FormatUtils.duration(video.metadata.durationMs)} • ${FormatUtils.fileSize(video.metadata.fileSizeBytes)}"
                    else -> ""
                }
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (video.unsupportedReason != null) MaterialTheme.colorScheme.error
                    else MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2
                )
            }
            when {
                video.unsupportedReason != null -> Icon(
                    Icons.Filled.ErrorOutline,
                    contentDescription = stringResource(R.string.cd_failed),
                    tint = MaterialTheme.colorScheme.error
                )
                video.isLoadingMetadata -> CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
            }
            IconButton(onClick = onRemove) {
                Icon(Icons.Filled.Close, contentDescription = stringResource(R.string.cd_cancel))
            }
        }
    }
}
