package com.variaflow.mobile.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.variaflow.mobile.data.VideoMetadata
import com.variaflow.mobile.util.FormatUtils

/**
 * Spec section 3's full metadata list, laid out as label/value rows. Used both for a
 * just-picked source video and, on the comparison screen, for the produced output.
 */
@Composable
fun VideoInfoCard(title: String, metadata: VideoMetadata, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text(
                metadata.displayName,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            InfoRow("File size", FormatUtils.fileSize(metadata.fileSizeBytes))
            InfoRow("Duration", FormatUtils.duration(metadata.durationMs))
            InfoRow("Resolution", FormatUtils.resolution(metadata.width, metadata.height))
            InfoRow("Frame rate", FormatUtils.fps(metadata.frameRate))
            InfoRow("Video codec", metadata.videoCodec)
            InfoRow("Audio codec", metadata.audioCodec ?: "No audio track")
            InfoRow("Bitrate", FormatUtils.bitrate(metadata.bitrateBps))
            InfoRow("Container", metadata.containerLabel)
            InfoRow("Audio sample rate", FormatUtils.sampleRate(metadata.audioSampleRateHz))
            InfoRow("Audio channels", FormatUtils.channelLabel(metadata.audioChannelCount))
        }
    }
}

@Composable
fun InfoRow(label: String, value: String, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier.fillMaxWidth().padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
    }
}
