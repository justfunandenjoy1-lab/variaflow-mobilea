package com.variaflow.mobile.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.variaflow.mobile.R
import com.variaflow.mobile.data.QualityWarning
import com.variaflow.mobile.ui.theme.SevereRed
import com.variaflow.mobile.ui.theme.WarningAmber as WarningAmberColor

/** Spec section 6: surfaced whenever settings are likely to cause visible quality loss. */
@Composable
fun WarningBanner(warnings: List<QualityWarning>, modifier: Modifier = Modifier) {
    if (warnings.isEmpty()) return
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        warnings.forEach { warning ->
            val color = if (warning.isSevere) SevereRed else WarningAmberColor
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = color.copy(alpha = 0.12f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(Modifier.padding(10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(
                        Icons.Filled.WarningAmber,
                        contentDescription = stringResource(R.string.cd_warning),
                        tint = color
                    )
                    Text(warning.message, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}
