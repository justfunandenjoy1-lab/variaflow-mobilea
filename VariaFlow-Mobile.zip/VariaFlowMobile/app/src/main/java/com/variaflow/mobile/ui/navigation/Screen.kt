package com.variaflow.mobile.ui.navigation

/**
 * VariaFlow is small enough that a plain sealed class + `when` in [com.variaflow.mobile.ui.VariaFlowApp]
 * is clearer than pulling in the Navigation-Compose library for two destinations.
 */
sealed class AppScreen {
    data object Home : AppScreen()
    data class Comparison(val jobId: String) : AppScreen()
}
