package com.variaflow.mobile.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.variaflow.mobile.data.ProcessingJob
import com.variaflow.mobile.ui.components.ComparisonCard
import com.variaflow.mobile.ui.components.VideoInfoCard
import com.variaflow.mobile.ui.components.WarningBanner

/** Spec section 7: the dedicated before/after comparison screen for one finished job. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ComparisonScreen(job: ProcessingJob, onBack: () -> Unit, onPlayOutput: () -> Unit, modifier: Modifier = Modifier) {
    val source = job.sourceMetadata
    val output = job.result?.outputMetadata

    Scaffold(
        modifier = modifier,
        topBar = {
            TopAppBar(
                title = { Text("Before / after") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") }
                }
            )
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (source != null && output != null) {
                ComparisonCard(original = source, output = output)
                WarningBanner(job.warnings)
                Button(onClick = onPlayOutput) {
                    Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.padding(end = 6.dp))
                    Text("Play processed video")
                }
                VideoInfoCard(title = "Original", metadata = source)
                VideoInfoCard(title = "Output", metadata = output)
            } else {
                Text(
                    "This job doesn't have full comparison data available.",
                    style = MaterialTheme.typography.bodyLarge
                )
            }
        }
    }
}
