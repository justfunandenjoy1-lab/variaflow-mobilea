package com.variaflow.mobile.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.variaflow.mobile.data.ProcessingJob
import com.variaflow.mobile.data.ProcessingSettings
import com.variaflow.mobile.data.ProcessingStage
import com.variaflow.mobile.data.QualityTier
import com.variaflow.mobile.media.QualityAdvisor
import com.variaflow.mobile.ui.components.BatchSummary
import com.variaflow.mobile.ui.components.JobRow
import com.variaflow.mobile.ui.components.PresetSelector
import com.variaflow.mobile.ui.components.SettingsPanel
import com.variaflow.mobile.ui.components.StagedVideoRow
import com.variaflow.mobile.ui.components.WarningBanner
import com.variaflow.mobile.viewmodel.StagedVideo

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    stagedVideos: List<StagedVideo>,
    settings: ProcessingSettings,
    jobs: List<ProcessingJob>,
    settingsSheetOpen: Boolean,
    outputFolderLabel: String,
    snackbarHostState: SnackbarHostState,
    onPickVideos: () -> Unit,
    onRemoveStaged: (String) -> Unit,
    onSelectPreset: (QualityTier) -> Unit,
    onOpenSettings: () -> Unit,
    onCloseSettings: () -> Unit,
    onUpdateSettings: ((ProcessingSettings) -> ProcessingSettings) -> Unit,
    onStartProcessing: () -> Unit,
    onCancelJob: (String) -> Unit,
    onViewComparison: (String) -> Unit,
    onDismissJob: (String) -> Unit,
    onOpenOutput: () -> Unit,
    modifier: Modifier = Modifier
) {
    Scaffold(
        modifier = modifier,
        topBar = { TopAppBar(title = { Text("VariaFlow Mobile") }) },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = padding.calculateTopPadding() + 12.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Button(onClick = onPickVideos, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Filled.VideoLibrary, contentDescription = null, modifier = Modifier.padding(end = 8.dp))
                    Text("Select Video")
                }
            }

            if (stagedVideos.isNotEmpty()) {
                item { Text("Video information", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold) }
                items(stagedVideos, key = { it.id }) { video ->
                    StagedVideoRow(video = video, onRemove = { onRemoveStaged(video.id) })
                }

                val previewWarnings = stagedVideos.singleOrNull()?.metadata?.let { QualityAdvisor.evaluate(it, settings) }
                if (!previewWarnings.isNullOrEmpty()) {
                    item { WarningBanner(previewWarnings) }
                }

                item {
                    Column {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Processing settings", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                            TextButton(onClick = onOpenSettings) {
                                Icon(Icons.Filled.Tune, contentDescription = null, modifier = Modifier.padding(end = 4.dp))
                                Text("Customize")
                            }
                        }
                        PresetSelector(selected = settings.preset, onSelect = onSelectPreset)
                    }
                }

                item {
                    Button(onClick = onStartProcessing, modifier = Modifier.fillMaxWidth()) {
                        Text(if (stagedVideos.size > 1) "Process ${stagedVideos.size} Videos" else "Process Video")
                    }
                }
            }

            if (jobs.isNotEmpty()) {
                item { HorizontalDivider(Modifier.padding(vertical = 4.dp)) }
                item {
                    Text("Processing queue", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                }
                item { BatchSummary(jobs) }
                items(jobs, key = { it.id }) { job ->
                    JobRow(
                        job = job,
                        onCancel = { onCancelJob(job.id) },
                        onViewComparison = { onViewComparison(job.id) },
                        onDismiss = { onDismissJob(job.id) }
                    )
                }
                if (jobs.any { it.stage == ProcessingStage.DONE }) {
                    item {
                        OutlinedButton(onClick = onOpenOutput, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Filled.FolderOpen, contentDescription = null, modifier = Modifier.padding(end = 8.dp))
                            Text("Open Output ($outputFolderLabel)")
                        }
                    }
                }
            }

            if (stagedVideos.isEmpty() && jobs.isEmpty()) {
                item {
                    Text(
                        "Pick a video to see its info, choose a preset, and convert it — " +
                            "entirely on this device.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 24.dp)
                    )
                }
            }
        }
    }

    if (settingsSheetOpen) {
        ModalBottomSheet(onDismissRequest = onCloseSettings) {
            SettingsPanel(settings = settings, onChange = onUpdateSettings)
        }
    }
}
