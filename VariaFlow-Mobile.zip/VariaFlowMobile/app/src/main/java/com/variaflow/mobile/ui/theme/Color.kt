package com.variaflow.mobile.ui.theme

import androidx.compose.ui.graphics.Color

// Brand accent — matches the launcher icon mark (ic_launcher_foreground.xml).
val VariaTeal = Color(0xFF35C7CF)
val VariaTealDark = Color(0xFF1C8B92)

val LightBackground = Color(0xFFF4F6F7)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE7ECEE)
val LightOnBackground = Color(0xFF141D1F)
val LightOnSurfaceVariant = Color(0xFF4A5B5E)

val DarkBackground = Color(0xFF0D1417)
val DarkSurface = Color(0xFF162023)
val DarkSurfaceVariant = Color(0xFF233033)
val DarkOnBackground = Color(0xFFE7F0F1)
val DarkOnSurfaceVariant = Color(0xFFA9BDC0)

val WarningAmber = Color(0xFFB98A1E)
val SevereRed = Color(0xFFD1495B)
val SuccessGreen = Color(0xFF2E9E63)
