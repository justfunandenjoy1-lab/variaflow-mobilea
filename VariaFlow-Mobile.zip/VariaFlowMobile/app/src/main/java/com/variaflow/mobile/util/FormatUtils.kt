package com.variaflow.mobile.util

import java.util.Locale
import kotlin.math.roundToInt

/** Human-readable formatting shared by every info/comparison card in the UI. */
object FormatUtils {

    fun fileSize(bytes: Long): String {
        if (bytes <= 0) return "—"
        val kb = 1024.0
        val mb = kb * 1024
        val gb = mb * 1024
        return when {
            bytes >= gb -> String.format(Locale.US, "%.2f GB", bytes / gb)
            bytes >= mb -> String.format(Locale.US, "%.1f MB", bytes / mb)
            bytes >= kb -> String.format(Locale.US, "%.0f KB", bytes / kb)
            else -> "$bytes B"
        }
    }

    fun duration(ms: Long): String {
        if (ms <= 0) return "—"
        val totalSeconds = ms / 1000
        val h = totalSeconds / 3600
        val m = (totalSeconds % 3600) / 60
        val s = totalSeconds % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
        else String.format(Locale.US, "%d:%02d", m, s)
    }

    fun bitrate(bps: Long): String {
        if (bps <= 0) return "—"
        val mbps = bps / 1_000_000.0
        return if (mbps >= 1) String.format(Locale.US, "%.1f Mbps", mbps)
        else String.format(Locale.US, "%.0f kbps", bps / 1000.0)
    }

    fun resolution(width: Int, height: Int): String =
        if (width > 0 && height > 0) "${width}×${height}" else "—"

    fun fps(frameRate: Float): String =
        if (frameRate > 0) "${frameRate.roundToInt()} fps" else "—"

    /** Percentage change from [from] to [to], formatted with a sign, e.g. "-42%". */
    fun percentChange(from: Long, to: Long): String {
        if (from <= 0) return "—"
        val change = ((to - from) * 100.0 / from).roundToInt()
        return if (change >= 0) "+$change%" else "$change%"
    }

    fun channelLabel(channels: Int?): String = when (channels) {
        null -> "—"
        1 -> "Mono"
        2 -> "Stereo"
        6 -> "5.1 surround"
        8 -> "7.1 surround"
        else -> "$channels channels"
    }

    fun sampleRate(hz: Int?): String = if (hz == null || hz <= 0) "—" else "${hz / 1000} kHz"
}
