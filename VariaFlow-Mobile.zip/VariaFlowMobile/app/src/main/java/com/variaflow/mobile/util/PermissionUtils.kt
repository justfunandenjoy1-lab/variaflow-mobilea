package com.variaflow.mobile.util

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat

/**
 * VariaFlow needs exactly one runtime permission: POST_NOTIFICATIONS, so the
 * foreground processing notification can show on Android 13+. Picking the
 * source video and saving the output both go through Storage Access
 * Framework / MediaStore, which need no storage permission from this app.
 */
object PermissionUtils {

    fun notificationPermissionRequired(): Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU

    fun hasNotificationPermission(context: Context): Boolean {
        if (!notificationPermissionRequired()) return true
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED
    }
}
