package com.variaflow.mobile.util

/**
 * Every failure VideoProcessor / ProcessingService can raise, each carrying a message
 * that is already safe and clear to show directly in the UI (per spec section 11 —
 * "simple human-readable error messages").
 */
sealed class VariaFlowException(message: String, cause: Throwable? = null) : Exception(message, cause) {

    class UnsupportedFormat(reason: String) :
        VariaFlowException(reason)

    class CorruptedFile(fileName: String) :
        VariaFlowException("\"$fileName\" looks corrupted or incomplete and couldn't be read.")

    class UnsupportedCodec(codecName: String) :
        VariaFlowException(
            "This device's hardware doesn't support the \"$codecName\" codec needed for this file " +
                "or the chosen output setting. Try a different output codec."
        )

    class InsufficientStorage :
        VariaFlowException("Not enough free storage space to save the processed video. Free up some space and try again.")

    class PermissionDenied(what: String) :
        VariaFlowException("VariaFlow needs $what permission to continue.")

    class DeviceMemoryLimitation :
        VariaFlowException("This device ran out of memory while processing. Try a lower resolution or close other apps.")

    class Cancelled :
        VariaFlowException("Processing was cancelled.")

    class Unknown(detail: String) :
        VariaFlowException("Something went wrong while processing this video: $detail")

    companion object {
        /** Maps whatever Media3 Transformer / IO throws into one of the friendly types above. */
        fun from(throwable: Throwable, fileName: String): VariaFlowException {
            val message = throwable.message.orEmpty()
            return when {
                throwable is java.io.FileNotFoundException ->
                    CorruptedFile(fileName)
                message.contains("ENOSPC", ignoreCase = true) || message.contains("space", ignoreCase = true) ->
                    InsufficientStorage()
                message.contains("OutOfMemory", ignoreCase = true) || throwable is OutOfMemoryError ->
                    DeviceMemoryLimitation()
                message.contains("codec", ignoreCase = true) || message.contains("decoder", ignoreCase = true) || message.contains("encoder", ignoreCase = true) ->
                    UnsupportedCodec(message.take(60))
                else -> Unknown(message.ifBlank { throwable::class.java.simpleName })
            }
        }
    }
}
