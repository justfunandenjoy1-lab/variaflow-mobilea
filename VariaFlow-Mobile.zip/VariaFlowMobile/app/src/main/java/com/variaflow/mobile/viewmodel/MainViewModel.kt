package com.variaflow.mobile.viewmodel

import android.app.Application
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.variaflow.mobile.data.ProcessingJob
import com.variaflow.mobile.data.ProcessingSettings
import com.variaflow.mobile.data.ProcessingStage
import com.variaflow.mobile.data.QualityTier
import com.variaflow.mobile.data.VideoMetadata
import com.variaflow.mobile.media.SupportedFormats
import com.variaflow.mobile.media.VideoInfoExtractor
import com.variaflow.mobile.service.ProcessingRepository
import com.variaflow.mobile.service.ProcessingService
import com.variaflow.mobile.storage.OutputFileManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

/** A picked-but-not-yet-queued video, while VariaFlow is still reading its metadata. */
data class StagedVideo(
    val id: String,
    val uri: Uri,
    val displayName: String,
    val metadata: VideoMetadata? = null,
    val isLoadingMetadata: Boolean = true,
    val unsupportedReason: String? = null
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val _stagedVideos = MutableStateFlow<List<StagedVideo>>(emptyList())
    val stagedVideos: StateFlow<List<StagedVideo>> = _stagedVideos.asStateFlow()

    private val _settings = MutableStateFlow(ProcessingSettings.forPreset(QualityTier.BALANCED))
    val settings: StateFlow<ProcessingSettings> = _settings.asStateFlow()

    private val _settingsSheetOpen = MutableStateFlow(false)
    val settingsSheetOpen: StateFlow<Boolean> = _settingsSheetOpen.asStateFlow()

    private val _comparisonJobId = MutableStateFlow<String?>(null)
    val comparisonJobId: StateFlow<String?> = _comparisonJobId.asStateFlow()

    private val _events = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val events: SharedFlow<String> = _events.asSharedFlow()

    /** Pass-through of the queue the foreground service actually works from. */
    val jobs: StateFlow<List<ProcessingJob>> = ProcessingRepository.jobs

    val outputFolderLabel: String = OutputFileManager.outputFolderLabel()

    // ---- Video selection ---------------------------------------------------------------

    fun onVideosPicked(uris: List<Uri>) {
        val context = getApplication<Application>()
        uris.forEach { uri ->
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: SecurityException) {
                // Some providers don't support persistable permissions; the read still works
                // for this session, it just won't survive a process death mid-queue.
            }

            val displayName = queryDisplayName(uri) ?: uri.lastPathSegment ?: "video"
            val formatCheck = SupportedFormats.check(displayName)

            if (formatCheck is com.variaflow.mobile.media.FormatCheckResult.Unsupported) {
                _events.tryEmit(formatCheck.reason)
                return@forEach
            }

            val stagedId = UUID.randomUUID().toString()
            _stagedVideos.update { it + StagedVideo(stagedId, uri, displayName) }

            viewModelScope.launch {
                val metadata = withContext(Dispatchers.IO) {
                    runCatching { VideoInfoExtractor.extract(context, uri, displayName) }.getOrNull()
                }
                _stagedVideos.update { list ->
                    list.map {
                        if (it.id == stagedId) {
                            if (metadata == null) {
                                it.copy(isLoadingMetadata = false, unsupportedReason = "Couldn't read this file — it may be corrupted.")
                            } else {
                                it.copy(metadata = metadata, isLoadingMetadata = false)
                            }
                        } else it
                    }
                }
            }
        }
    }

    fun removeStagedVideo(id: String) {
        _stagedVideos.update { list -> list.filterNot { it.id == id } }
    }

    // ---- Settings ------------------------------------------------------------------------

    fun selectPreset(tier: QualityTier) {
        _settings.value = ProcessingSettings.forPreset(tier)
    }

    fun updateSettings(transform: (ProcessingSettings) -> ProcessingSettings) {
        _settings.update { current ->
            val updated = transform(current)
            if (updated == current) updated else updated.copy(preset = QualityTier.CUSTOM)
        }
    }

    fun openSettingsSheet() { _settingsSheetOpen.value = true }
    fun closeSettingsSheet() { _settingsSheetOpen.value = false }

    // ---- Processing ------------------------------------------------------------------------

    fun startProcessing() {
        val ready = _stagedVideos.value.filter { it.unsupportedReason == null }
        if (ready.isEmpty()) {
            _events.tryEmit("Select at least one video first.")
            return
        }
        val currentSettings = _settings.value
        val newJobs = ready.map { staged ->
            ProcessingJob(
                id = UUID.randomUUID().toString(),
                inputUri = staged.uri,
                inputDisplayName = staged.displayName,
                settings = currentSettings,
                sourceMetadata = staged.metadata,
                stage = ProcessingStage.QUEUED
            )
        }
        ProcessingRepository.enqueue(newJobs)
        _stagedVideos.value = emptyList()
        ProcessingService.kick(getApplication())
    }

    fun cancelJob(id: String) = ProcessingRepository.requestCancel(id)

    fun removeFinishedJob(id: String) = ProcessingRepository.removeJob(id)

    fun clearFinishedJobs() = ProcessingRepository.clearFinished()

    // ---- Comparison screen -----------------------------------------------------------------

    fun showComparison(jobId: String) { _comparisonJobId.value = jobId }
    fun closeComparison() { _comparisonJobId.value = null }

    // ---- helpers -------------------------------------------------------------------------

    private fun queryDisplayName(uri: Uri): String? {
        val context = getApplication<Application>()
        return context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (nameIndex != -1 && cursor.moveToFirst()) cursor.getString(nameIndex) else null
        }
    }
}
