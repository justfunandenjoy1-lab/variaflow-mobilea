// Top-level build file where you can add configuration options common to all sub-projects/modules.
// Versions pinned here are known-current as of September 2026. If a future version
// of Android Studio suggests an update, it is safe to accept it.
plugins {
    id("com.android.application") version "8.13.2" apply false
    id("org.jetbrains.kotlin.android") version "2.2.21" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.2.21" apply false
}

tasks.register("clean", Delete::class) {
    delete(rootProject.buildDir)
}
